package com.cg.covidvaccination.service;

import javax.validation.Valid;

import com.cg.covidvaccination.entity.BookedSlot;
import com.cg.covidvaccination.entity.Employee;
import com.cg.covidvaccination.entity.MedicalStaff;
import com.cg.covidvaccination.entity.Slot;

public interface IMedicalStaffService {

	public String MedicalStaffLogin(int Id, String password);

	public MedicalStaff signOut(MedicalStaff medicalStaff);

	int getRandomNumberUsingInts(int min, int max);

	public String Updatedose1prebp(int userid, String dose1_Pre_BP);

	public BookedSlot addbookedSlot1(@Valid BookedSlot bokedslot);

	Employee updateDose1_Pre_Temp(int userid, String dose1_Pre_temp); 
	Employee updateDose1_Pre_BP(int userid, String dose1_Pre_BP);
	Employee updateDose1_Pre_Sat(int userid, String dose1_Pre_Sat);
	Employee updateDose1_Post_BP(int userid, String dose1_Post_BP);
	Employee updateDose1_Post_Sat(int userid, String dose1_Post_Sat);
	Employee updateDose1_Post_Temp(int userid, String dose1_Post_Temp);
	Employee updateDose2_Pre_BP(int userid, String dose2_Pre_BP) ;
	Employee updateDose2_Pre_Temp(int userid, String dose2_Pre_Temp);
	Employee updateDose2_Post_BP(int userid, String dose2_Post_BP);
	Employee updateDose2_Post_Sat(int userid, String dose2_Post_Sat);
	Employee updateDose2_Post_Temp(int userid, String dose1_Post_Temp) ;
	Employee updateDose2_Pre_Sat(int userid, String dose2_Pre_Sat);

	Employee updateDose2certid(int userid);

	Employee updateDose1certid(int userid);
	
	
	
	
	
	
	
	
	
	
	
	
	
}
