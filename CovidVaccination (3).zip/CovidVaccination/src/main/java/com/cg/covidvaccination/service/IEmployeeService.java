package com.cg.covidvaccination.service;

import java.util.List;
import java.util.Optional;

import com.cg.covidvaccination.entity.Employee;

public interface IEmployeeService {
	
	
}
