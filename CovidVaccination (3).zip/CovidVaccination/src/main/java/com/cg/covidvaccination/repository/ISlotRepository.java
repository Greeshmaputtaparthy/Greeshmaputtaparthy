package com.cg.covidvaccination.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.covidvaccination.entity.Slot;

@Repository
public interface ISlotRepository extends JpaRepository<Slot, Integer> {
	public Slot findBySlotId(int slotId);
	
	public boolean existsBySlotId(int slotId);
	
	@Query("select s.slotNumbers from Slot s where s.slotId=:slotId") 
	public int getSlotNumbers(@Param("slotId")int slotId);
	
//	@Modifying(clearAutomatically = true)
//	@Query("update Slot s set s.slotNumbers=:existsSlot-1  where s.slotId=:slotId")
//	public Slot updateslotNumbers(@Param("slotId")int slotId,@Param("existsSlot") int existsslot);
//	
	
}
