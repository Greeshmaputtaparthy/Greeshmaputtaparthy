package com.cg.covidvaccination.service;

import java.util.List;

import com.cg.covidvaccination.entity.Slot;
import com.cg.covidvaccination.exception.SlotExistsException;
import com.cg.covidvaccination.exception.SlotNotFoundException;

public interface ISlotService {

	Slot bookSlot(int slotId) throws SlotNotFoundException;

	Slot cancelSlotBooking(int slotId) throws SlotNotFoundException;

	Slot blockSlot(int slotId) throws SlotNotFoundException;

	Slot addSlot(Slot slot);

	List<Slot> getAllSlots() throws SlotNotFoundException;
	
}
