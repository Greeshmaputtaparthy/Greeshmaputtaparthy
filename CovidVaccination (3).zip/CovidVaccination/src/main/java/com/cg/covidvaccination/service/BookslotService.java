package com.cg.covidvaccination.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.covidvaccination.entity.BookedSlot;
import com.cg.covidvaccination.entity.BookingState;
import com.cg.covidvaccination.entity.Employee;
import com.cg.covidvaccination.entity.Slot;
import com.cg.covidvaccination.exception.EmployeeExistsException;
import com.cg.covidvaccination.exception.SlotNotFoundException;
import com.cg.covidvaccination.repository.IBookedSlotRepository;

@Service
@Transactional
public class BookslotService implements IBookslotService {
	@Autowired
	IBookedSlotRepository repository;

	
	@Override

	public BookedSlot addbookedSlot1(BookedSlot bookedSlot) {
	if (repository.existsByemployeeId(bookedSlot.getEmployeeId())) {
		
		throw new EmployeeExistsException("Employee Id exists already"); // 
	} else {
		BookedSlot bookedSlotobj = repository.save(bookedSlot);
		
		return bookedSlotobj;
	}
	}


	@Override
	public String Updatedose1prebp(int userid, String dose1_Pre_Temp) {
		// TODO Auto-generated method stub
		return null;
	}	
}