package com.cg.covidvaccination.controller;


import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.covidvaccination.entity.Slot;
import com.cg.covidvaccination.exception.SlotExistsException;
import com.cg.covidvaccination.exception.SlotNotFoundException;
import com.cg.covidvaccination.service.ISlotService;

@RestController
@RequestMapping("/mts/slot")
public class SlotController {
	@Autowired
	ISlotService service;

	Logger logger = LoggerFactory.getLogger(SlotController.class);

	@PostMapping("/bookSlot")
	public ResponseEntity<Object> bookSlot(@RequestParam int slotId)  {
		logger.info("Inside bookSlot method");
		Slot slotData = null;
		try {
			slotData = service.bookSlot(slotId);
			return new ResponseEntity<Object>(slotData, HttpStatus.OK);
		} catch (SlotNotFoundException e) {
			// TODO Auto-generated catch block
			logger.error("Slot Not Found Exception");
			e.printStackTrace();
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		
	}

	@PutMapping("/cancelSlot")
	public ResponseEntity<Object> cancelSlot(@RequestParam int slotId) {
		logger.info("Inside cancelSlot method");
		Slot slotData;
		try {
			slotData = service.cancelSlotBooking(slotId);
			return new ResponseEntity<Object>(slotData, HttpStatus.OK);
		} catch (SlotNotFoundException e) {
			// TODO Auto-generated catch block
			logger.error("Slot Not Found Exception");
			e.printStackTrace();
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		
	}

	@PutMapping("/blockSlot")
	public ResponseEntity<Object> blockSlot(@RequestParam int slotId) {
		Slot slotData;
		logger.info("Inside blockSlot method");
		try {
			slotData = service.blockSlot(slotId);
			return new ResponseEntity<Object>(slotData, HttpStatus.OK);

		} catch (SlotNotFoundException e) {
			// TODO Auto-generated catch block
			logger.error("Slot Not Found Exception");
			e.printStackTrace();
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	
	@PostMapping("/addNewSlot")
	public ResponseEntity<Object> addNewSlot(@Valid @RequestBody Slot slot){
		Slot slotData=null;
		try {
			slotData = service.addSlot(slot);
			return new ResponseEntity<Object>(slotData, HttpStatus.OK);
		} catch (SlotExistsException e) {
			// TODO Auto-generated catch block
			logger.error("Slot Exists Exception");
			//e.printStackTrace();
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/getAvailableSlots")
	public ResponseEntity<Object> getAllSlots() {
		List<Slot> slotList;
		try {
			slotList = service.getAllSlots();
			return new ResponseEntity<Object>(slotList,HttpStatus.OK);
		} catch (SlotNotFoundException e) {
			// TODO Auto-generated catch block
			logger.error("Slot Not Found Exception");
			e.printStackTrace();
			return new ResponseEntity<Object>(e.getMessage(),HttpStatus.BAD_REQUEST);
		}
	}


}
