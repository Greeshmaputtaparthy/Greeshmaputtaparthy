package com.cg.covidvaccination.exception;

import java.util.Date;

public class EmployeeIdNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private Date timestamp;
	private String message;

	public EmployeeIdNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public EmployeeIdNotFoundException(String message) {
		super(message);
	}

	@Override
	public String toString() {
		return "MessageIdNotFoundException [timestamp=" + timestamp + ", message=" + message + "]";
	}
}
