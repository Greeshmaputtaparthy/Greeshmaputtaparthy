package com.cg.covidvaccination.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;

public class EmployeeExistsException extends RuntimeException {
	public EmployeeExistsException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
