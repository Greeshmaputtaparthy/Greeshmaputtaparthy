
package com.cg.covidvaccination.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.covidvaccination.entity.Employee;
import com.cg.covidvaccination.exception.EmployeeExistsException;
import com.cg.covidvaccination.exception.EmployeeNotFoundException;
//import com.cg.covidvaccination.EmployeeNotFoundException;
import com.cg.covidvaccination.exception.InvalidDataException;
import com.cg.covidvaccination.repository.IEmployeeRepository;

@Service
@Transactional
public class EmployeeService implements IEmployeeService {

	@Autowired
	IEmployeeRepository repository;

	Logger logger = LoggerFactory.getLogger(EmployeeService.class);

	
	public Employee getempId(int employeeid) {
		Optional<Employee> optional = repository.findById(employeeid);
		Employee employee=null;
		
		if(optional.isPresent()) {
			employee=optional.get();
			
		}
		return employee;
		
	}
	
	public Employee updateempdose1pretemp(int employeeid,String dose_1) {
		
		Employee employee=getempId( employeeid);
		
		if(employee!=null) {
			employee.setDose1PreTemp(dose_1);
			
		}
		return employee;
		
	}
	
	
	public Employee updateempdose1prebp(int employeeid,String dose_1) {
		
		Employee employee=getempId( employeeid);
		
		if(employee!=null) {
			employee.setDose1PreBP(dose_1);
			
		}
		return employee;
		
	}
	
	public Employee updateempdose1presat(int employeeid,String dose_1) {
		
		Employee employee=getempId( employeeid);
		
		if(employee!=null) {
			employee.setDose1PreSat(dose_1);
			
		}
		return employee;
		
	}
	public Employee updateempdose2prebp(int employeeid,String dose_2) {
		
		Employee employee=getempId( employeeid);
		
		if(employee!=null) {
			employee.setDose2PreBP(dose_2);
			
		}
		return employee;
		
	}
	public Employee updateempdose2pretemp(int employeeid,String dose_2) {
		
		Employee employee=getempId( employeeid);
		
		if(employee!=null) {
			employee.setDose2PreTemp(dose_2);
			
		}
		return employee;
		
	}
	public Employee updateempdose2presat(int employeeid,String dose_2) {
		
		Employee employee=getempId( employeeid);
		
		if(employee!=null) {
			employee.setDose2PreSat(dose_2);
			
		}
		return employee;
		
	}

	public Employee updateempdose1posttemp(int employeeid,String dose_1) {
		
		Employee employee=getempId( employeeid);
		
		if(employee!=null) {
			employee.setDose1PostTemp(dose_1);
			
		}
		return employee;
		
	}
	
	
	public Employee updateempdose1postbp(int employeeid,String dose_1) {
		
		Employee employee=getempId( employeeid);
		
		if(employee!=null) {
			employee.setDose1PostBP(dose_1);
			
		}
		return employee;
		
	}
	
	public Employee updateempdose1postsat(int employeeid,String dose_1) {
		
		Employee employee=getempId( employeeid);
		
		if(employee!=null) {
			employee.setDose1PostSat(dose_1);
			
		}
		return employee;
		
	}
	public Employee updateempdose2postbp(int employeeid,String dose_2) {
		
		Employee employee=getempId( employeeid);
		
		if(employee!=null) {
			employee.setDose2PostBP(dose_2);
			
		}
		return employee;
		
	}
	public Employee updateempdose2posttemp(int employeeid,String dose_2) {
		
		Employee employee=getempId( employeeid);
		
		if(employee!=null) {
			employee.setDose2PostTemp(dose_2);
			
		}
		return employee;
		
	}
	public Employee updateempdose2postsat(int employeeid,String dose_2) {
		
		Employee employee=getempId( employeeid);
		
		if(employee!=null) {
			employee.setDose2PostSat(dose_2);
			
		}
		return employee;
	
		
	}
	
	public Employee updateempdose1certid(int employeeid) {
		
		Employee employee=getempId(employeeid);
		
		if(employee!=null) {
			employee.setDose1CertID(Math.random());
			
		}
		return employee;
		
	}
	
	public Employee updateempdose2certid(int employeeid) {
		
		Employee employee=getempId( employeeid);
		
		if(employee!=null) {
			employee.setDose2CertID(Math.random());
			
		}
		return employee;
		
	}
	
	
	}

	
	





