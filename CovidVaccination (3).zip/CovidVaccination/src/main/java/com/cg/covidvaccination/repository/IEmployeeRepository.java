
package com.cg.covidvaccination.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.covidvaccination.entity.Employee;

@Repository
public interface IEmployeeRepository extends JpaRepository<Employee, Integer> {
	//public Employee findByEmployeeIdAndPasswordAndRole(int employeeId, String password, String role);

	public boolean existsByEmployeeId(int employeeId);
	public Employee findByEmployeeId(int employeeId);
	//Optional<Employee> findByRoleAndPassword(String role, String password);
}
