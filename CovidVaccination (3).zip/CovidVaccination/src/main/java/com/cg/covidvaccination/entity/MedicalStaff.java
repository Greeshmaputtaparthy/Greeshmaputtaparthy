package com.cg.covidvaccination.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "medicalStaff_master")
public class MedicalStaff {


	@Id
	@Column(name = "medicalStaffId")
	@GeneratedValue
	private int medicalStaffId;
	
	@Column(name = "medicalStaffName", length = 30)
	private String medicalStaffName;

	@Column(name = "password", length = 30)
	private String password;
	
	@Column(name = "location", length = 100)
	private String location;
	
	
	public MedicalStaff() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MedicalStaff(int medicalStaffId, String password) {
		super();
		this.medicalStaffId = medicalStaffId;
		this.password = password;
	}
	public int getMedicalStaffId() {
		return medicalStaffId;
	}

	public void setMedicalStaffId(int medicalStaffId) {
		this.medicalStaffId = medicalStaffId;
	}

	public String getMedicalStaffName() {
		return medicalStaffName;
	}

	public void setMedicalStaffName(String medicalStaffName) {
		this.medicalStaffName = medicalStaffName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "MedicalStaff [medicalStaffId=" + medicalStaffId + ", medicalStaffName=" + medicalStaffName
				+ ", location=" + location + "]";
	}


	
}

