package com.cg.covidvaccination.controller;

import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.covidvaccination.entity.BookedSlot;
import com.cg.covidvaccination.entity.Employee;
import com.cg.covidvaccination.entity.MedicalStaff;
import com.cg.covidvaccination.entity.Slot;
import com.cg.covidvaccination.exception.SlotExistsException;
import com.cg.covidvaccination.repository.IBookedSlotRepository;
import com.cg.covidvaccination.repository.IEmployeeRepository;
import com.cg.covidvaccination.service.EmployeeService;
import com.cg.covidvaccination.service.IBookslotService;
import com.cg.covidvaccination.service.IMedicalStaffService;

@RestController
@RequestMapping("/medicalStaff")
public class MedicalStaffController {

	@Autowired
	IMedicalStaffService service;

	@Autowired
	IEmployeeRepository Repository1;
	// @Autowired
	// EmployeeService service2;

	@Autowired
	IBookedSlotRepository bookedSlotRepository;

	@Autowired
	IBookslotService service1;

	
	Logger logger = LoggerFactory.getLogger(MedicalStaffController.class);

	@PostMapping(value = "/SignIn/{loginID}/{Password}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> MedicalStaffSignin(@PathVariable(value = "loginID") int loginid,
			@PathVariable(value = "Password") String password, HttpServletRequest request) {

		String medicalStaffData = service.MedicalStaffLogin(loginid, password);
		HttpSession session = request.getSession();

		if (medicalStaffData != null) {
			session.setAttribute("UserExists", medicalStaffData);
			logger.info("Login successfully!" + medicalStaffData);

			return new ResponseEntity<String>("Login successfully!", HttpStatus.CREATED);
		} else {
			logger.info("Login Failed!!!");
			return new ResponseEntity<String>(medicalStaffData, HttpStatus.BAD_REQUEST);
		}

	}

	@PostMapping("/signOut")
	public ResponseEntity<String> MedicalStaffSignOut(HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.removeAttribute("UserExists");
		session.invalidate();
		return new ResponseEntity<String>("Sign Out succesfull", HttpStatus.OK);
	}

	@GetMapping(value = "/GetEmplyeeSchedule/{UserID}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BookedSlot> checkEmployeeScheduled(@PathVariable(value = "UserID") int userid,
			HttpServletRequest request) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		HttpSession session = request.getSession();
		BookedSlot bookedSlot = bookedSlotRepository.findByemployeeId(userid);
		if (bookedSlot != null) {
			session.setAttribute("UserExists", bookedSlot);
			return new ResponseEntity<BookedSlot>(bookedSlot, HttpStatus.OK);
		} else {
			return new ResponseEntity<BookedSlot>(bookedSlot, HttpStatus.OK);
		}
	}

	@PostMapping("/addBookedSlot")
	public ResponseEntity<Object> addBookedSlot(@Valid @RequestBody BookedSlot bokedslot) {
		BookedSlot slotData = null;
		try {
			slotData = service.addbookedSlot1(bokedslot);
			return new ResponseEntity<Object>(slotData, HttpStatus.OK);
		} catch (SlotExistsException e) {
			// TODO Auto-generated catch block
			logger.error("Slot Exists Exception");
			// e.printStackTrace();
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}

	}

	@PatchMapping(value = "/UpdateDose1_Pre_BP/{UserID}/{Dose1_Pre_BP}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose1_Pre_BP(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose1_Pre_BP") String Dose1_Pre_BP, HttpServletRequest request) {
		Employee k = service.updateDose1_Pre_BP(userid, Dose1_Pre_BP);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}

	@PatchMapping(value = "/UpdateDose1_Pre_Temp/{UserID}/{Dose1_Pre_Temp}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose1_Pre_Temp(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose1_Pre_Temp") String Dose1_Pre_Temp, HttpServletRequest request) {
		Employee k = service.updateDose1_Pre_Temp(userid, Dose1_Pre_Temp);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}

	@PatchMapping(value = "/UpdateDose1_Pre_Sat/{UserID}/{Dose1_Pre_Sat}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose1_Pre_Sat(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose1_Pre_Sat") String Dose1_Pre_Sat, HttpServletRequest request) {
		Employee k = service.updateDose1_Pre_Sat(userid, Dose1_Pre_Sat);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);
	}

	@PatchMapping(value = "/UpdateDose1_Post_BP/{UserID}/{Dose1_Post_BP}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose1_Post_BP(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose1_Post_BP") String Dose1_Post_BP, HttpServletRequest request) {
		Employee k = service.updateDose1_Post_BP(userid, Dose1_Post_BP);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);
	}

	@PatchMapping(value = "/UpdateDose1_Post_Sat/{UserID}/{Dose1_Post_Sat}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose1_Post_Sat(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose1_Post_Sat") String Dose1_Post_Sat, HttpServletRequest request) {
		Employee k = service.updateDose1_Post_Sat(userid, Dose1_Post_Sat);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}

	@PatchMapping(value = "/UpdateDose1_Post_Temp/{UserID}/{Dose1_Post_Temp}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose1_Post_Temp(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose1_Post_Temp") String Dose1_Post_Temp, HttpServletRequest request) {
		Employee k = service.updateDose1_Post_Temp(userid, Dose1_Post_Temp);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}

	@PatchMapping(value = "/UpdateDose2_Pre_BP/{UserID}/{Dose2_Pre_BP}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose2_Pre_BP(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose2_Pre_BP") String Dose2_Pre_BP, HttpServletRequest request) {
		Employee k = service.updateDose2_Pre_BP(userid, Dose2_Pre_BP);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);
	}

	@PatchMapping(value = "/UpdateDose2_Pre_Sat/{UserID}/{Dose2_Pre_Sat}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose2_Pre_Sat(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose2_Pre_Sat") String Dose2_Pre_Sat, HttpServletRequest request) {
		Employee k = service.updateDose2_Pre_Sat(userid, Dose2_Pre_Sat);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}

	@PatchMapping(value = "/UpdateDose2_Pre_Temp/{UserID}/{Dose2_Pre_Temp}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose2_Pre_Temp(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose2_Pre_Temp") String Dose2_Pre_Temp, HttpServletRequest request) {
		Employee k = service.updateDose2_Pre_Temp(userid, Dose2_Pre_Temp);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);//

	}

	@PatchMapping(value = "/UpdateDose2_Post_BP/{UserID}/{Dose2_Post_BP}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose2_Post_BP(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose2_Post_BP") String Dose2_Post_BP, HttpServletRequest request) {
		Employee k = service.updateDose2_Post_BP(userid, Dose2_Post_BP);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}

	@PatchMapping(value = "/UpdateDose2_Post_Sat/{UserID}/{Dose2_Post_Sat}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose2_Post_Sat(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose2_Post_Sat") String Dose2_Post_Sat, HttpServletRequest request) {
		Employee k = service.updateDose2_Post_Sat(userid, Dose2_Post_Sat);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);
	}

	@PatchMapping(value = "/UpdateDose2_Post_Temp/{UserID}/{Dose2_Post_Temp}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose2_Post_Temp(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose2_Post_Temp") String Dose2_Post_Temp, HttpServletRequest request) {
		Employee k = service.updateDose2_Post_Temp(userid, Dose2_Post_Temp);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}
	
	@PatchMapping(value = "/UpdateDose1_Certid/{UserID}{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> UpdateDose1_Certid(@PathVariable(value = "UserID") int userid
			 , HttpServletRequest request) {
		Employee k = service.updateDose1certid(userid);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}
	
	@PatchMapping(value = "/UpdateDose2_Certid/{UserID}{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> UpdateDose2Certid(@PathVariable(value = "UserID") int userid,
			 HttpServletRequest request) {
		Employee k = service.updateDose2certid(userid);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}
}
