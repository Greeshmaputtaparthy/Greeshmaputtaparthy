package com.cg.covidvaccination.entity;

public enum BookingState {
	Available,Booked,Blocked;
}
