package com.cg.covidvaccination.service;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.covidvaccination.entity.BookingState;
import com.cg.covidvaccination.entity.Slot;
import com.cg.covidvaccination.exception.SlotExistsException;
import com.cg.covidvaccination.exception.SlotNotFoundException;
import com.cg.covidvaccination.repository.ISlotRepository;

@Service
@Transactional
public class SlotService implements ISlotService {

	@Autowired
	ISlotRepository repository;
	
	Logger logger = LoggerFactory.getLogger(SlotService.class);
	@Override
	public Slot bookSlot(int slotId) throws SlotNotFoundException {
		logger.info("Inside bookSlot method");
		Slot newSlot = repository.findBySlotId(slotId);
		if(newSlot == null) {
			logger.error("Exception in bookSlot method");
			throw new SlotNotFoundException("Invalid Slot Id");
		}
		else {
			
			int existsSlotNumbers = repository.getSlotNumbers(slotId);
			logger.info("**"+existsSlotNumbers);
//			Slot updatedSlot = repository.updateslotNumbers(slotId,existsSlotNumbers);
			newSlot.setSlotNumbers(existsSlotNumbers-1);
			Slot updatedSlot = repository.save(newSlot);
			
			
			newSlot.setState(BookingState.Booked);
			logger.info("Slot Booked");
			return updatedSlot;
		}
		
		
	}
	
	

	@Override
	
	public Slot cancelSlotBooking(int slotId) throws SlotNotFoundException {
		logger.info("Inside cancelSlotBooking method");
		Slot newSlot = repository.findBySlotId(slotId);
		if(newSlot == null) {
			logger.error("Exception in cancelSlotBooking method");
			throw new SlotNotFoundException("Invalid Slot Id");
		}
		else {
			newSlot.setState(BookingState.Available);
			logger.info("Slot Cancelled");
			return newSlot;
		}
	}

	
	@Override
	public Slot blockSlot(int slotId) throws SlotNotFoundException {
		logger.info("Inside blockSlot method");
		Slot newSlot = repository.findBySlotId(slotId);
		if(newSlot == null){
			logger.error("Exception in blockSlot method");
			throw new SlotNotFoundException("Invalid Slot Id");
		}
		else {
			newSlot.setState(BookingState.Blocked);
			logger.info("Slot Blocked");
			return newSlot;
		}
	}
	


	
	@Override
	public Slot addSlot(Slot slot) {
		if(repository.existsById(slot.getSlotId())) {
			logger.error("Slot Already exists");
			throw new SlotExistsException("Slot Id already exists");
		}
		Slot newSlot = repository.save(slot);
		logger.info("New Slot Added");
		return newSlot;
	}
	
	@Override
	public List<Slot> getAllSlots() throws SlotNotFoundException {
		logger.info("Inside getAll method");
		List<Slot> slotList = repository.findAll();
		if(slotList.isEmpty()){
			logger.error("Slot Database is empty");
			throw new SlotNotFoundException("Slot Database is empty");
		}
		else
			return slotList;
	}
	
}
