package com.cg.covidvaccination.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


@Entity
@Table(name = "employee_table")
@Inheritance(strategy = InheritanceType.JOINED)
public class Employee {
	@Id

	private int employeeId;
	private String password;
	@Column(name = "employeeName")
	private String employeeName;
	@Column(name = "Dose1_Date")
	private Date Dose1Date;
	@Column(name = "Dose2_Date")
	private Date Dose2Date;
	@Column(name = "Dose1_Location")
	private String Dose1Location;
	@Column(name = "Dose2_Location")
	private String Dose2Location;
	@Column(name = "Dose1_Pre_BP")
	private String Dose1PreBP;
	@Column(name = "Dose1_Pre_Sat")
	private String Dose1PreSat;
	@Column(name = "Dose1_Pre_Temp")
	private String Dose1PreTemp;
	@Column(name = "Dose1_Post_BP")
	private String Dose1PostBP;
	@Column(name = "Dose1_Post_Sat")
	private String Dose1PostSat;
	@Column(name = "Dose1_Post_Temp")
	private String Dose1PostTemp;
	@Column(name = "Dose1_CertID")
	private double Dose1CertID;
	@Column(name = "Dose2_Pre_BP")
	private String Dose2PreBP;
	@Column(name = "Dose2_Pre_Sat")
	private String Dose2PreSat;
	@Column(name = "Dose2_Pre_Temp")
	private String Dose2PreTemp;
	@Column(name = "Dose2_Post_BP")
	private String Dose2PostBP;
	@Column(name = "Dose2_Post_Sat")
	private String Dose2PostSat;
	@Column(name = "Dose2_Post_Temp")
	private String Dose2PostTemp;
	@Column(name = "Dose2_CertID")
	private double Dose2CertID;
	private int attempts;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int employeeId, String password, String employeeName, Date dose1Date, Date dose2Date,
			String dose1Location, String dose2Location, String dose1PreBP, String dose1PreSat, String dose1PreTemp,
			String dose1PostBP, String dose1PostSat, String dose1PostTemp, int dose1CertID, String dose2PreBP,
			String dose2PreSat, String dose2PreTemp, String dose2PostBP, String dose2PostSat, String dose2PostTemp,
			int dose2CertID, int attempts) {
		super();
		this.employeeId = employeeId;
		this.password = password;
		this.employeeName = employeeName;
		Dose1Date = dose1Date;
		Dose2Date = dose2Date;
		Dose1Location = dose1Location;
		Dose2Location = dose2Location;
		Dose1PreBP = dose1PreBP;
		Dose1PreSat = dose1PreSat;
		Dose1PreTemp = dose1PreTemp;
		Dose1PostBP = dose1PostBP;
		Dose1PostSat = dose1PostSat;
		Dose1PostTemp = dose1PostTemp;
		Dose1CertID = dose1CertID;
		Dose2PreBP = dose2PreBP;
		Dose2PreSat = dose2PreSat;
		Dose2PreTemp = dose2PreTemp;
		Dose2PostBP = dose2PostBP;
		Dose2PostSat = dose2PostSat;
		Dose2PostTemp = dose2PostTemp;
		Dose2CertID = dose2CertID;
		this.attempts = attempts;
	}
	public Employee(int employeeId,  String password, int attempts) {
		this.employeeId=employeeId;
		
		this.password=password;
		this.attempts=attempts;
		// TODO Auto-generated constructor stub
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Date getDose1Date() {
		return Dose1Date;
	}
	public void setDose1Date(Date dose1Date) {
		Dose1Date = dose1Date;
	}
	public Date getDose2Date() {
		return Dose2Date;
	}
	public void setDose2Date(Date dose2Date) {
		Dose2Date = dose2Date;
	}
	public String getDose1Location() {
		return Dose1Location;
	}
	public void setDose1Location(String dose1Location) {
		Dose1Location = dose1Location;
	}
	public String getDose2Location() {
		return Dose2Location;
	}
	public void setDose2Location(String dose2Location) {
		Dose2Location = dose2Location;
	}
	public String getDose1PreBP() {
		return Dose1PreBP;
	}
	public void setDose1PreBP(String dose1PreBP) {
		Dose1PreBP = dose1PreBP;
	}
	public String getDose1PreSat() {
		return Dose1PreSat;
	}
	public void setDose1PreSat(String dose1PreSat) {
		Dose1PreSat = dose1PreSat;
	}
	public String getDose1PreTemp() {
		return Dose1PreTemp;
	}
	public void setDose1PreTemp(String dose1PreTemp) {
		Dose1PreTemp = dose1PreTemp;
	}
	public String getDose1PostBP() {
		return Dose1PostBP;
	}
	public void setDose1PostBP(String dose1PostBP) {
		Dose1PostBP = dose1PostBP;
	}
	public String getDose1PostSat() {
		return Dose1PostSat;
	}
	public void setDose1PostSat(String dose1PostSat) {
		Dose1PostSat = dose1PostSat;
	}
	public String getDose1PostTemp() {
		return Dose1PostTemp;
	}
	public void setDose1PostTemp(String dose1PostTemp) {
		Dose1PostTemp = dose1PostTemp;
	}
	public double getDose1CertID() {
		return Dose1CertID;
	}
	public void setDose1CertID(double d) {
		Dose1CertID = d;
	}
	public String getDose2PreBP() {
		return Dose2PreBP;
	}
	public void setDose2PreBP(String dose2PreBP) {
		Dose2PreBP = dose2PreBP;
	}
	public String getDose2PreSat() {
		return Dose2PreSat;
	}
	public void setDose2PreSat(String dose2PreSat) {
		Dose2PreSat = dose2PreSat;
	}
	public String getDose2PreTemp() {
		return Dose2PreTemp;
	}
	public void setDose2PreTemp(String dose2PreTemp) {
		Dose2PreTemp = dose2PreTemp;
	}
	public String getDose2PostBP() {
		return Dose2PostBP;
	}
	public void setDose2PostBP(String dose2PostBP) {
		Dose2PostBP = dose2PostBP;
	}
	public String getDose2PostSat() {
		return Dose2PostSat;
	}
	public void setDose2PostSat(String dose2PostSat) {
		Dose2PostSat = dose2PostSat;
	}
	public String getDose2PostTemp() {
		return Dose2PostTemp;
	}
	public void setDose2PostTemp(String dose2PostTemp) {
		Dose2PostTemp = dose2PostTemp;
	}
	public double getDose2CertID() {
		return Dose2CertID;
	}
	public void setDose2CertID(double d) {
		Dose2CertID = d;
	}
	public int getAttempts() {
		return attempts;
	}
	public void setAttempts(int attempts) {
		this.attempts = attempts;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", password=" + password + ", employeeName=" + employeeName
				+ ", Dose1Date=" + Dose1Date + ", Dose2Date=" + Dose2Date + ", Dose1Location=" + Dose1Location
				+ ", Dose2Location=" + Dose2Location + ", Dose1PreBP=" + Dose1PreBP + ", Dose1PreSat=" + Dose1PreSat
				+ ", Dose1PreTemp=" + Dose1PreTemp + ", Dose1PostBP=" + Dose1PostBP + ", Dose1PostSat=" + Dose1PostSat
				+ ", Dose1PostTemp=" + Dose1PostTemp + ", Dose1CertID=" + Dose1CertID + ", Dose2PreBP=" + Dose2PreBP
				+ ", Dose2PreSat=" + Dose2PreSat + ", Dose2PreTemp=" + Dose2PreTemp + ", Dose2PostBP=" + Dose2PostBP
				+ ", Dose2PostSat=" + Dose2PostSat + ", Dose2PostTemp=" + Dose2PostTemp + ", Dose2CertID=" + Dose2CertID
				+ ", attempts=" + attempts + "]";
	}
	public String getRole() {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
	
}
