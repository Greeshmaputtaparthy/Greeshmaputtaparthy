package com.cg.covidvaccination.service;

import java.util.Optional;
import java.util.Random;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.covidvaccination.entity.BookedSlot;
import com.cg.covidvaccination.entity.Employee;
import com.cg.covidvaccination.entity.MedicalStaff;
import com.cg.covidvaccination.entity.Slot;
import com.cg.covidvaccination.exception.InvalidDataException;
import com.cg.covidvaccination.repository.IMedicalStaffRepository;

@Service
@Transactional
public class MedicalStaffService implements  IMedicalStaffService{
	@Autowired
	EmployeeService employeeservice; 
	
	@Autowired
	IMedicalStaffRepository repository;
	
	@Override
	public String MedicalStaffLogin(int Id, String password) {
		Optional<MedicalStaff> opmedicalEntity = repository.findByMedicalStaffIdAndPassword(Id, password);
		if(opmedicalEntity.isPresent())
		{
			MedicalStaff medicalEntity = opmedicalEntity.get();
				
					if(medicalEntity.getPassword().equals(password)){
						return "1";
						}		
		}
		else
		{
					return null;
		}
		return null;

	}

	@Override
	public MedicalStaff signOut(MedicalStaff medicalStaff) {
		// TODO Auto-generated method stub
		return medicalStaff;
	}
	@Override
	public int getRandomNumberUsingInts(int min, int max) {
	    Random random = new Random();
	    return random.ints(min, max)
	      .findFirst()
	      .getAsInt();
	  //  app.user-age=${random.int(100)};
	   // mployee.certificate_id=,${random.int(100)}
	}

	
	public Employee updateDose1_Pre_Temp(int userid, String dose1_Pre_temp) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose1pretemp(userid, dose1_Pre_temp);
		return emptemp;
	}

	
	
	public Employee updateDose1_Pre_BP(int userid, String dose1_Pre_BP) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose1prebp(userid, dose1_Pre_BP);
		return emptemp;
	}
	
	public Employee updateDose1_Pre_Sat(int userid, String dose1_Pre_Sat) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose1presat(userid, dose1_Pre_Sat);
		return emptemp;
	}
	
	public Employee updateDose1_Post_BP(int userid, String dose1_Post_BP) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose1postbp(userid, dose1_Post_BP);
		return emptemp;
	}
	
	public Employee updateDose1_Post_Sat(int userid, String dose1_Post_Sat) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose1postsat(userid, dose1_Post_Sat);
		return emptemp;
	}
	
	public Employee updateDose1_Post_Temp(int userid, String dose1_Post_Temp) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose1posttemp(userid, dose1_Post_Temp);
		return emptemp;
	}
	
	public Employee updateDose2_Pre_BP(int userid, String dose2_Pre_BP) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose2prebp(userid, dose2_Pre_BP);
		return emptemp;
	}
	public Employee updateDose2_Pre_Sat(int userid, String dose2_Pre_Sat) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose2presat(userid, dose2_Pre_Sat);
		return emptemp;
	}
	
	public Employee updateDose2_Pre_Temp(int userid, String dose2_Pre_Temp) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose2pretemp(userid, dose2_Pre_Temp);
		return emptemp;
	}

	
	public Employee updateDose2_Post_BP(int userid, String dose2_Post_BP) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose2postbp(userid, dose2_Post_BP);
		return emptemp;
	}
	public Employee updateDose2_Post_Sat(int userid, String dose2_Post_Sat) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose2postsat(userid, dose2_Post_Sat);
		return emptemp;
	}
	public Employee updateDose2_Post_Temp(int userid, String dose1_Post_Temp) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose2posttemp(userid, dose1_Post_Temp);
		return emptemp;
	}

	public Employee updateDose1certid(int userid) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose1certid(userid);
		return emptemp;
	}

	
	public Employee updateDose2certid(int userid) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose2certid(userid);
		return emptemp;
	}

	
	@Override
	public BookedSlot addbookedSlot1(@Valid BookedSlot bokedslot) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String Updatedose1prebp(int userid, String dose1_Pre_BP) {
		// TODO Auto-generated method stub
		return null;
	}


	
	
}


