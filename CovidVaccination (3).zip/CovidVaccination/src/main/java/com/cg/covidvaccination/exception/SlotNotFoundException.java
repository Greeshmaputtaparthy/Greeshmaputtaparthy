package com.cg.covidvaccination.exception;

public class SlotNotFoundException extends RuntimeException {
	public SlotNotFoundException(String message) {
		super(message);
	}
}

