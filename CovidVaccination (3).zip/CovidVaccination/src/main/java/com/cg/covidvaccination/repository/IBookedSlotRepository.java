package com.cg.covidvaccination.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.covidvaccination.entity.BookedSlot;




public interface IBookedSlotRepository extends JpaRepository<BookedSlot, Integer> {

	public BookedSlot findByemployeeId(int employeeId);

	public boolean existsByemployeeId(int employeeId);
	
}
