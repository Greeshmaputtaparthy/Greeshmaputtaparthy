package com.covidvaccination;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CovidVaccinationApplicationTests {

	@Test
	void contextLoads() {
	}

}
