package com.cg.covidvaccination.exception;

public class EmployeeNotFoundException extends RuntimeException {
	
	

}
