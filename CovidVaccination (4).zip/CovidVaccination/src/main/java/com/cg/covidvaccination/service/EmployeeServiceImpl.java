//package com.cg.covidvaccination.service;
//
//
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//
//import com.cg.covidvaccination.entity.Employee;
//import com.cg.covidvaccination.repository.IEmployeeRepository;
//
//@Service
//public class EmployeeServiceImpl implements IEmployeeService {
//
//	@Autowired
//	private IEmployeeRepository employeeRepository;
//
//	@Override
//	public List<Employee> getEmployees() {
//		List<Employee> employeeList = employeeRepository.findAll();
//		return employeeList;
//	}
//
//	@Override
//	public Employee getEmployee(int employeeId) {
//		Optional<Employee> message = employeeRepository.findById(employeeId);
//		return (message.isPresent()) ? message.get() : null;
//	}
//
//	@Override
//	public Employee deleteEmployee(int employeeId) {
//		Employee message = getEmployee(employeeId);
//		if (message != null)
//		employeeRepository.deleteById(employeeId);
//		return message;
//	}
//
//	@Override
//	public Employee updateEmployee(int employeeId, Employee employee) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public Employee insertEmployee(Employee employee) {
//		// TODO Auto-generated method stub
//		return null;
//	}


//	
//	
//}
