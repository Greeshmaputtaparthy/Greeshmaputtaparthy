package com.cg.covidvaccination.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "BookedSlot")
public class BookedSlot 
{
	@Id
	@Column(name = "employeeId")
	private int employeeId;
	@Column(name = "SlotDate")
	private Date SlotDate;
	@Column(name = "SlotLocation")
	private String SlotLocation;
	@Column(name = "DoseNumber")
	private int DoseNumber;
	public BookedSlot(int employeeId, Date slotDate, String slotLocation, int doseNumber) {
		super();
		this.employeeId = employeeId;
		SlotDate = slotDate;
		SlotLocation = slotLocation;
		DoseNumber = doseNumber;
	}
	public BookedSlot() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public Date getSlotDate() {
		return SlotDate;
	}
	public void setSlotDate(Date slotDate) {
		SlotDate = slotDate;
	}
	public String getSlotLocation() {
		return SlotLocation;
	}
	public void setSlotLocation(String slotLocation) {
		SlotLocation = slotLocation;
	}
	public int getDoseNumber() {
		return DoseNumber;
	}
	public void setDoseNumber(int doseNumber) {
		DoseNumber = doseNumber;
	}
	@Override
	public String toString() {
		return "BookedSlot [employeeId=" + employeeId + ", SlotDate=" + SlotDate + ", SlotLocation=" + SlotLocation
				+ ", DoseNumber=" + DoseNumber + "]";
	}
	
	
	

}
