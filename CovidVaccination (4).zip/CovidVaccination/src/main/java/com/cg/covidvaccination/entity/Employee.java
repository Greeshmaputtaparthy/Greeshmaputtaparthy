package com.cg.covidvaccination.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


@Entity
@Table(name = "employeetable")
@Inheritance(strategy = InheritanceType.JOINED)
public class Employee {
	@Id

	private int employeeId;
	private String password;
	@Column(name = "employeeName")
	private String employeeName;
	@Column(name = "dose1Date")
	private Date dose1Date;
	@Column(name = "dose2Date")
	private Date dose2Date;
	@Column(name = "dose1Location")
	private String dose1Location;
	@Column(name = "dose2Location")
	private String dose2Location;
	@Column(name = "dose1PreBP")
	private String dose1PreBP;
	@Column(name = "dose1PreSat")
	private String dose1PreSat;
	@Column(name = "dose1PreTemp")
	private String dose1PreTemp;
	@Column(name = "dose1PostBP")
	private String dose1PostBP;
	@Column(name = "dose1PostSat")
	private String dose1PostSat;
	@Column(name = "dose1PostTemp")
	private String dose1PostTemp;
	@Column(name = "dose1CertID")
	private double dose1CertID;
	@Column(name = "dose2PreBP")
	private String dose2PreBP;
	@Column(name = "dose2PreSat")
	private String dose2PreSat;
	@Column(name = "dose2PreTemp")
	private String dose2PreTemp;
	@Column(name = "dose2PostBP")
	private String dose2PostBP;
	@Column(name = "dose2PostSat")
	private String dose2PostSat;
	@Column(name = "dose2PostTemp")
	private String dose2PostTemp;
	@Column(name = "dose2CertID")
	private double dose2CertID;
	private int attempts;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Employee(int employeeId, String password, String employeeName, Date dose1Date, Date dose2Date,
			String dose1Location, String dose2Location, String dose1PreBP, String dose1PreSat, String dose1PreTemp,
			String dose1PostBP, String dose1PostSat, String dose1PostTemp, double dose1CertID, String dose2PreBP,
			String dose2PreSat, String dose2PreTemp, String dose2PostBP, String dose2PostSat, String dose2PostTemp,
			double dose2CertID, int attempts) {
		super();
		this.employeeId = employeeId;
		this.password = password;
		this.employeeName = employeeName;
		this.dose1Date = dose1Date;
		this.dose2Date = dose2Date;
		this.dose1Location = dose1Location;
		this.dose2Location = dose2Location;
		this.dose1PreBP = dose1PreBP;
		this.dose1PreSat = dose1PreSat;
		this.dose1PreTemp = dose1PreTemp;
		this.dose1PostBP = dose1PostBP;
		this.dose1PostSat = dose1PostSat;
		this.dose1PostTemp = dose1PostTemp;
		this.dose1CertID = dose1CertID;
		this.dose2PreBP = dose2PreBP;
		this.dose2PreSat = dose2PreSat;
		this.dose2PreTemp = dose2PreTemp;
		this.dose2PostBP = dose2PostBP;
		this.dose2PostSat = dose2PostSat;
		this.dose2PostTemp = dose2PostTemp;
		this.dose2CertID = dose2CertID;
		this.attempts = attempts;
	}

	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Date getDose1Date() {
		return dose1Date;
	}
	public void setDose1Date(Date dose1Date) {
		this.dose1Date = dose1Date;
	}
	public Date getDose2Date() {
		return dose2Date;
	}
	public void setDose2Date(Date dose2Date) {
		this.dose2Date = dose2Date;
	}
	public String getDose1Location() {
		return dose1Location;
	}
	public void setDose1Location(String dose1Location) {
		this.dose1Location = dose1Location;
	}
	public String getDose2Location() {
		return dose2Location;
	}
	public void setDose2Location(String dose2Location) {
		this.dose2Location = dose2Location;
	}
	public String getDose1PreBP() {
		return dose1PreBP;
	}
	public void setDose1PreBP(String dose1PreBP) {
		this.dose1PreBP = dose1PreBP;
	}
	public String getDose1PreSat() {
		return dose1PreSat;
	}
	public void setDose1PreSat(String dose1PreSat) {
		this.dose1PreSat = dose1PreSat;
	}
	public String getDose1PreTemp() {
		return dose1PreTemp;
	}
	public void setDose1PreTemp(String dose1PreTemp) {
		this.dose1PreTemp = dose1PreTemp;
	}
	public String getDose1PostBP() {
		return dose1PostBP;
	}
	public void setDose1PostBP(String dose1PostBP) {
		this.dose1PostBP = dose1PostBP;
	}
	public String getDose1PostSat() {
		return dose1PostSat;
	}
	public void setDose1PostSat(String dose1PostSat) {
		this.dose1PostSat = dose1PostSat;
	}
	public String getDose1PostTemp() {
		return dose1PostTemp;
	}
	public void setDose1PostTemp(String dose1PostTemp) {
		this.dose1PostTemp = dose1PostTemp;
	}
	public double getDose1CertID() {
		return dose1CertID;
	}
	public void setDose1CertID(double dose1CertID) {
		this.dose1CertID = dose1CertID;
	}
	public String getDose2PreBP() {
		return dose2PreBP;
	}
	public void setDose2PreBP(String dose2PreBP) {
		this.dose2PreBP = dose2PreBP;
	}
	public String getDose2PreSat() {
		return dose2PreSat;
	}
	public void setDose2PreSat(String dose2PreSat) {
		this.dose2PreSat = dose2PreSat;
	}
	public String getDose2PreTemp() {
		return dose2PreTemp;
	}
	public void setDose2PreTemp(String dose2PreTemp) {
		this.dose2PreTemp = dose2PreTemp;
	}
	public String getDose2PostBP() {
		return dose2PostBP;
	}
	public void setDose2PostBP(String dose2PostBP) {
		this.dose2PostBP = dose2PostBP;
	}
	public String getDose2PostSat() {
		return dose2PostSat;
	}
	public void setDose2PostSat(String dose2PostSat) {
		this.dose2PostSat = dose2PostSat;
	}
	public String getDose2PostTemp() {
		return dose2PostTemp;
	}
	public void setDose2PostTemp(String dose2PostTemp) {
		this.dose2PostTemp = dose2PostTemp;
	}
	public double getDose2CertID() {
		return dose2CertID;
	}
	public void setDose2CertID(double dose2CertID) {
		this.dose2CertID = dose2CertID;
	}
	public int getAttempts() {
		return attempts;
	}
	public void setAttempts(int attempts) {
		this.attempts = attempts;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", password=" + password + ", employeeName=" + employeeName
				+ ", dose1Date=" + dose1Date + ", dose2Date=" + dose2Date + ", dose1Location=" + dose1Location
				+ ", dose2Location=" + dose2Location + ", dose1PreBP=" + dose1PreBP + ", dose1PreSat=" + dose1PreSat
				+ ", dose1PreTemp=" + dose1PreTemp + ", dose1PostBP=" + dose1PostBP + ", dose1PostSat=" + dose1PostSat
				+ ", dose1PostTemp=" + dose1PostTemp + ", dose1CertID=" + dose1CertID + ", dose2PreBP=" + dose2PreBP
				+ ", dose2PreSat=" + dose2PreSat + ", dose2PreTemp=" + dose2PreTemp + ", dose2PostBP=" + dose2PostBP
				+ ", dose2PostSat=" + dose2PostSat + ", dose2PostTemp=" + dose2PostTemp + ", dose2CertID=" + dose2CertID
				+ ", attempts=" + attempts + "]";
	}
	
	
}
