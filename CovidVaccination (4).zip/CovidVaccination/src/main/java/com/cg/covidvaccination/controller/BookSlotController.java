//package com.cg.covidvaccination.controller;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.cg.covidvaccination.entity.Slot;
//import com.cg.covidvaccination.exception.SlotNotFoundException;
//import com.cg.covidvaccination.service.ISlotService;
//
//@RestController
//@RequestMapping("/mts/bookslot")
//public class BookSlotController {
//	
//	@Autowired
//	IBookslotService service;
//
//	Logger logger = LoggerFactory.getLogger(SlotController.class);
//
//	@PostMapping("/bookSlot")
//	public ResponseEntity<Object> bookSlot(@RequestParam int slotId)  {
//		logger.info("Inside bookSlot method");
//		Slot slotData = null;
//		try {
//			slotData = service.bookSlot(slotId);
//			return new ResponseEntity<Object>(slotData, HttpStatus.OK);
//		} catch (SlotNotFoundException e) {
//			// TODO Auto-generated catch block
//			logger.error("Slot Not Found Exception");
//			e.printStackTrace();
//			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.BAD_REQUEST);
//		}
//		
//	}
//
//
//}
