package com.cg.covidvaccination.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.covidvaccination.entity.MedicalStaff;


public interface IMedicalStaffRepository extends JpaRepository<MedicalStaff, Integer> {

	Optional<MedicalStaff> findByMedicalStaffIdAndPassword(int id, String password);

}
