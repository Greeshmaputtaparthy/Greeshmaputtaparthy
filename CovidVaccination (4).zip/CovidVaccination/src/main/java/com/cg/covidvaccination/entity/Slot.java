package com.cg.covidvaccination.entity;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

//import org.checkerframework.common.value.qual.IntVal;

@Entity
@Table(name = "slot_master")
public class Slot {
	@Id
	@GeneratedValue
	private int slotId;

//	@NotEmpty(message = "SlotNumber must not be empty")
//	@Pattern(regexp ="^[A-Z][0-9]{2}$",message="Enter proper slotnumber")
	
	@GeneratedValue(strategy=GenerationType.AUTO, generator="slotNumbers")
	private int slotNumbers;
	
	private String vaccineName;

	private BookingState state;

	public Slot() {
		
	}
	
	public Slot(int slotId, int slotNumbers, String vaccineName, BookingState state) {
		super();
		this.slotId = slotId;
		this.slotNumbers = slotNumbers;
		this.vaccineName = vaccineName;
		this.state = state;
	}

	public int getSlotId() {
		return slotId;
	}

	public void setSlotId(int slotId) {
		this.slotId = slotId;
	}

	public int getSlotNumbers() {
		return slotNumbers;
	}

	public void setSlotNumbers(int slotNumbers) {
		this.slotNumbers = slotNumbers;
	}

	public String getVaccineName() {
		return vaccineName;
	}

	public void setVaccineName(String vaccineName) {
		this.vaccineName = vaccineName;
	}

	public BookingState getState() {
		return state;
	}

	public void setState(BookingState state) {
		this.state = state;
	}

}
