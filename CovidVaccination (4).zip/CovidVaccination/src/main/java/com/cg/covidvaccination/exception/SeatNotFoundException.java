package com.cg.covidvaccination.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

public class SeatNotFoundException extends Exception {
	public SeatNotFoundException(String message) {
		super(message);
	}
}
