package com.cg.covidvaccination.service;

import java.util.List;

import com.cg.covidvaccination.entity.BookedSlot;
import com.cg.covidvaccination.entity.Slot;
import com.cg.covidvaccination.exception.SlotNotFoundException;

public interface IBookslotService {
	public BookedSlot addbookedSlot1( BookedSlot bookslot);

	public String Updatedose1prebp(int userid, String dose1_Pre_Temp);
	
}
