package com.cg.covidvaccination.exception;

public class SlotExistsException extends RuntimeException {
	public SlotExistsException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
