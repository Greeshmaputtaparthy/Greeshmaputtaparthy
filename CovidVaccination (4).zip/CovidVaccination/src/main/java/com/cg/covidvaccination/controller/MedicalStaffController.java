 package com.cg.covidvaccination.controller;

import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.covidvaccination.entity.BookedSlot;
import com.cg.covidvaccination.entity.Employee;
import com.cg.covidvaccination.entity.MedicalStaff;
import com.cg.covidvaccination.entity.Slot;
import com.cg.covidvaccination.exception.SlotExistsException;
import com.cg.covidvaccination.repository.IBookedSlotRepository;
import com.cg.covidvaccination.repository.IEmployeeRepository;
import com.cg.covidvaccination.service.EmployeeService;
import com.cg.covidvaccination.service.IBookslotService;
import com.cg.covidvaccination.service.IMedicalStaffService;

@RestController
@RequestMapping("/medicalStaff")
public class MedicalStaffController {

	@Autowired
	IMedicalStaffService service;

	@Autowired
	IEmployeeRepository Repository1;
	// @Autowired
	// EmployeeService service2;

	@Autowired
	IBookedSlotRepository bookedSlotRepository;

	@Autowired
	IBookslotService service1;

	
	Logger logger = LoggerFactory.getLogger(MedicalStaffController.class);

	@PostMapping(value = "/SignIn/{loginID}/{Password}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> MedicalStaffSignin(@PathVariable(value = "loginID") int loginid,
			@PathVariable(value = "Password") String password, HttpServletRequest request) {

		String medicalStaffData = service.MedicalStaffLogin(loginid, password);
		HttpSession session = request.getSession();

		if (medicalStaffData != null) {
			session.setAttribute("UserExists", medicalStaffData);
			logger.info("Login successfully!" + medicalStaffData);

			return new ResponseEntity<String>("Login successfully!", HttpStatus.CREATED);
		} else {
			logger.info("Login Failed!!!");
			return new ResponseEntity<String>(medicalStaffData, HttpStatus.BAD_REQUEST);
		}

	}

	@PostMapping("/signOut")
	public ResponseEntity<String> MedicalStaffSignOut(HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.removeAttribute("UserExists");
		session.invalidate();
		return new ResponseEntity<String>("Sign Out succesfull", HttpStatus.OK);
	}

	@GetMapping(value = "/GetEmplyeeSchedule/{UserID}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BookedSlot> checkEmployeeScheduled(@PathVariable(value = "UserID") int userid,
			HttpServletRequest request) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		HttpSession session = request.getSession();
		BookedSlot bookedSlot = bookedSlotRepository.findByemployeeId(userid);
		if (bookedSlot != null) {
			session.setAttribute("UserExists", bookedSlot);
			return new ResponseEntity<BookedSlot>(bookedSlot, HttpStatus.OK);
		} else {
			return new ResponseEntity<BookedSlot>(bookedSlot, HttpStatus.OK);
		}
	}

//	@PostMapping("/addBookedSlot")
//	public ResponseEntity<Object> addBookedSlot(@Valid @RequestBody BookedSlot bokedslot) {
//		BookedSlot slotData = null;
//		try {
//			slotData = service.addbookedSlot1(bokedslot);
//			return new ResponseEntity<Object>(slotData, HttpStatus.OK);
//		} catch (SlotExistsException e) {
//			// TODO Auto-generated catch block
//			logger.error("Slot Exists Exception");
//			// e.printStackTrace();
//			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.BAD_REQUEST);
//		}
//
//	}

	@PatchMapping(value = "/UpdateDose1PreBP/{UserID}/{Dose1PreBP}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose1PreBP(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose1PreBP") String Dose1PreBP, HttpServletRequest request) {
		Employee k = service.updatedose1PreBP(userid, Dose1PreBP);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}

	@PatchMapping(value = "/UpdateDose1PreTemp/{UserID}/{Dose1PreTemp}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose1PreTemp(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose1PreTemp") String Dose1PreTemp, HttpServletRequest request) {
		Employee k = service.updatedose1PreTemp(userid, Dose1PreTemp);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}

	@PatchMapping(value = "/UpdateDose1PreSat/{UserID}/{Dose1PreSat}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose1PreSat(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose1PreSat") String Dose1PreSat, HttpServletRequest request) {
		Employee k = service.updatedose1PreSat(userid, Dose1PreSat);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);
	}

	@PatchMapping(value = "/UpdateDose1PostBP/{UserID}/{Dose1PostBP}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose1PostBP(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose1PostBP") String Dose1PostBP, HttpServletRequest request) {
		Employee k = service.updatedose1PostBP(userid, Dose1PostBP);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);
	}

	@PatchMapping(value = "/UpdateDose1PostSat/{UserID}/{Dose1PostSat}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose1PostSat(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose1PostSat") String Dose1PostSat, HttpServletRequest request) {
		Employee k = service.updatedose1PostSat(userid, Dose1PostSat);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}

	@PatchMapping(value = "/UpdateDose1PostTemp/{UserID}/{Dose1PostTemp}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose1PostTemp(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose1PostTemp") String Dose1PostTemp, HttpServletRequest request) {
		Employee k = service.updatedose1PostTemp(userid, Dose1PostTemp);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}

	@PatchMapping(value = "/UpdateDose2PreBP/{UserID}/{Dose2PreBP}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose2PreBP(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose2PreBP") String Dose2PreBP, HttpServletRequest request) {
		Employee k = service.updatedose2PreBP(userid, Dose2PreBP);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);
	}

	@PatchMapping(value = "/UpdateDose2PreSat/{UserID}/{Dose2PreSat}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose2PreSat(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose2PreSat") String Dose2PreSat, HttpServletRequest request) {
		Employee k = service.updatedose2PreSat(userid, Dose2PreSat);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}

	@PatchMapping(value = "/UpdateDose2PreTemp/{UserID}/{Dose2PreTemp}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose2PreTemp(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose2PreTemp") String Dose2PreTemp, HttpServletRequest request) {
		Employee k = service.updatedose2PreTemp(userid, Dose2PreTemp);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);//

	}

	@PatchMapping(value = "/UpdateDose2PostBP/{UserID}/{Dose2PostBP}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose2PostBP(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose2PostBP") String Dose2PostBP, HttpServletRequest request) {
		Employee k = service.updatedose2PostBP(userid, Dose2PostBP);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}

	@PatchMapping(value = "/UpdateDose2PostSat/{UserID}/{Dose2PostSat}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose2PostSat(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose2PostSat") String Dose2PostSat, HttpServletRequest request) {
		Employee k = service.updatedose2PostSat(userid, Dose2PostSat);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);
	}

	@PatchMapping(value = "/UpdateDose2PostTemp/{UserID}/{Dose2PostTemp}/{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateDose2PostTemp(@PathVariable(value = "UserID") int userid,
			@PathVariable(value = "Dose2PostTemp") String Dose2PostTemp, HttpServletRequest request) {
		Employee k = service.updatedose2PostTemp(userid, Dose2PostTemp);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}
	
	@PatchMapping(value = "/UpdateDose1Certid/{UserID}{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> UpdateDose1Certid(@PathVariable(value = "UserID") int userid
			 , HttpServletRequest request) {
		Employee k = service.updatedose1CertID(userid);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}
	
	@PatchMapping(value = "/UpdateDose2Certid/{UserID}{", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> UpdateDose2Certid(@PathVariable(value = "UserID") int userid,
			 HttpServletRequest request) {
		Employee k = service.updatedose2CertID(userid);

		return new ResponseEntity<Employee>(k, HttpStatus.OK);

	}
}               
