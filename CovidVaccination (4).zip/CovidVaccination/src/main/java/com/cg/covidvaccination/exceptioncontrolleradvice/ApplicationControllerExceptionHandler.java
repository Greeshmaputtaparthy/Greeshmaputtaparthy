package com.cg.covidvaccination.exceptioncontrolleradvice;



import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.cg.covidvaccination.exception.EmployeeIdNotFoundException;

@ControllerAdvice
public class ApplicationControllerExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(EmployeeIdNotFoundException.class) // more exceptions
	public ResponseEntity<?> handleMissingStaffMember(EmployeeIdNotFoundException me) {
		Map<String, Object> errorMessage = new LinkedHashMap<>();
		errorMessage.put("error", "wrong message id");
		errorMessage.put("timestamp", LocalDateTime.now());
		errorMessage.put("details", me.getMessage());

		return new ResponseEntity<>(errorMessage, HttpStatus.NOT_FOUND);
	}

	// More methods for all controllers
}
