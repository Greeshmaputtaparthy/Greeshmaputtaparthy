package com.cg.covidvaccination.service;

import javax.validation.Valid;

import com.cg.covidvaccination.entity.BookedSlot;
import com.cg.covidvaccination.entity.Employee;
import com.cg.covidvaccination.entity.MedicalStaff;
import com.cg.covidvaccination.entity.Slot;

public interface IMedicalStaffService {

	public String MedicalStaffLogin(int Id, String password);

	public MedicalStaff signOut(MedicalStaff medicalStaff);

	int getRandomNumberUsingInts(int min, int max);


	Employee updatedose1PreTemp(int userid, String dose1Pretemp); 
	Employee updatedose1PreBP(int userid, String dose1PreBP);
	Employee updatedose1PreSat(int userid, String dose1PreSat);
	Employee updatedose1PostBP(int userid, String dose1PostBP);
	Employee updatedose1PostSat(int userid, String dose1PostSat);
	Employee updatedose1PostTemp(int userid, String dose1PostTemp);
	Employee updatedose2PreBP(int userid, String dose2PreBP) ;
	Employee updatedose2PreTemp(int userid, String dose2PreTemp);
	Employee updatedose2PostBP(int userid, String dose2PostBP);
	Employee updatedose2PostSat(int userid, String dose2PostSat);
	Employee updatedose2PostTemp(int userid, String dose1PostTemp) ;
	Employee updatedose2PreSat(int userid, String dose2PreSat);

	Employee updatedose2CertID(int userid);

	Employee updatedose1CertID(int userid);
	
	
	
	
	
	
	
	
	
	
	
	
	
}
