package com.cg.covidvaccination.service;

import java.util.Optional;
import java.util.Random;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.covidvaccination.entity.BookedSlot;
import com.cg.covidvaccination.entity.Employee;
import com.cg.covidvaccination.entity.MedicalStaff;
import com.cg.covidvaccination.entity.Slot;
import com.cg.covidvaccination.exception.InvalidDataException;
import com.cg.covidvaccination.repository.IMedicalStaffRepository;

@Service
@Transactional
public class MedicalStaffService implements  IMedicalStaffService{
	@Autowired
	EmployeeService employeeservice; 
	
	@Autowired
	IMedicalStaffRepository repository;
	
	@Override
	public String MedicalStaffLogin(int Id, String password) {
		Optional<MedicalStaff> opmedicalEntity = repository.findByMedicalStaffIdAndPassword(Id, password);
		if(opmedicalEntity.isPresent())
		{
			MedicalStaff medicalEntity = opmedicalEntity.get();
				
					if(medicalEntity.getPassword().equals(password)){
						return "1";
						}		
		}
		else
		{
					return null;
		}
		return null;

	}

	@Override
	public MedicalStaff signOut(MedicalStaff medicalStaff) {
		// TODO Auto-generated method stub
		return medicalStaff;
	}
	@Override
	public int getRandomNumberUsingInts(int min, int max) {
	    Random random = new Random();
	    return random.ints(min, max)
	      .findFirst()
	      .getAsInt();
	  //  app.user-age=${random.int(100)};
	   // mployee.certificateid=,${random.int(100)}
	}

	
	public Employee updatedose1PreTemp(int userid, String dose1Pretemp) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose1pretemp(userid, dose1Pretemp);
		return emptemp;
	}

	
	
	public Employee updatedose1PreBP(int userid, String dose1PreBP) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose1prebp(userid, dose1PreBP);
		return emptemp;
	}
	
	public Employee updatedose1PreSat(int userid, String dose1PreSat) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose1presat(userid, dose1PreSat);
		return emptemp;
	}
	
	public Employee updatedose1PostBP(int userid, String dose1PostBP) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose1postbp(userid, dose1PostBP);
		return emptemp;
	}
	
	public Employee updatedose1PostSat(int userid, String dose1PostSat) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose1postsat(userid, dose1PostSat);
		return emptemp;
	}
	
	public Employee updatedose1PostTemp(int userid, String dose1PostTemp) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose1posttemp(userid, dose1PostTemp);
		return emptemp;
	}
	
	public Employee updatedose2PreBP(int userid, String dose2PreBP) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose2prebp(userid, dose2PreBP);
		return emptemp;
	}
	public Employee updatedose2PreSat(int userid, String dose2PreSat) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose2presat(userid, dose2PreSat);
		return emptemp;
	}
	
	public Employee updatedose2PreTemp(int userid, String dose2PreTemp) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose2pretemp(userid, dose2PreTemp);
		return emptemp;
	}

	
	public Employee updatedose2PostBP(int userid, String dose2PostBP) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose2postbp(userid, dose2PostBP);
		return emptemp;
	}
	public Employee updatedose2PostSat(int userid, String dose2PostSat) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose2postsat(userid, dose2PostSat);
		return emptemp;
	}
	public Employee updatedose2PostTemp(int userid, String dose1PostTemp) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose2posttemp(userid, dose1PostTemp);
		return emptemp;
	}

	public Employee updatedose1CertID(int userid) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose1certid(userid);
		return emptemp;
	}

	
	public Employee updatedose2CertID(int userid) {
		// TODO Auto-generated method stub
		Employee emptemp=employeeservice.updateempdose2certid(userid);
		return emptemp;
	}




	
	
	
	
}


